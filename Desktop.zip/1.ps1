﻿# --- Detect if we are in 64-bit PowerShell ---
if ([Environment]::Is64BitProcess) {
    Write-Host "Running in 64-bit PowerShell. Switching to 32-bit..."

    $syswow64 = "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $syswow64)) {
        throw "32-bit PowerShell not found at $syswow64"
    }

    # Re-run this script in 32-bit PowerShell
    & $syswow64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}

Write-Host "Running in 32-bit PowerShell."

# --- Load DLL ---
$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
Add-Type -Path $dllPath -ErrorAction Stop

# --- Read and reverse Base64 ---
$revBase64 = Get-Content -Raw -Path "base64.txt"
$chars = $revBase64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# --- Install AssemblyResolve handler ---
Write-Host "=== Installing AssemblyResolve handler ==="
[System.AppDomain]::CurrentDomain.add_AssemblyResolve({
    param($sender, $args)
    Write-Warning "Missing assembly requested: $($args.Name)"
    return $null
})

# --- Run ---
try {
    $instance = New-Object Company.SafeIngest.SafeIngest
    $instance.RunBase64($fixedBase64)
    Write-Host "RunBase64 executed successfully in 32-bit mode."
}
catch {
    Write-Error "Error while invoking RunBase64: $($_.Exception.Message)"
    exit 1
}
