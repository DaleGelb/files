﻿# 1.ps1 — автоперезапуск PowerShell под нужный битнесс (x86/x64)

$ErrorActionPreference = 'Stop'

function Get-PEArch {
    param([byte[]]$Bytes)
    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" } # 'MZ'
    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }
    if ($Bytes[$e_lfanew] -ne 0x50 -or $Bytes[$e_lfanew+1] -ne 0x45) { return "unknown" } # 'PE'
    $magic = [BitConverter]::ToUInt16($Bytes, $e_lfanew + 0x18)
    switch ($magic) {
        0x10B { return "x86" }
        0x20B { return "x64" }
        default { return "unknown" }
    }
}

# === 1) Определяем архитектуру DLL и при необходимости перезапускаем PowerShell ===
$dllPath  = (Resolve-Path ".\Company.SafeIngest.dll").Path
$dllBytes = [System.IO.File]::ReadAllBytes($dllPath)
$dllArch  = Get-PEArch $dllBytes
$is64PS   = [Environment]::Is64BitProcess

if ($dllArch -eq "x86" -and $is64PS) {
    Write-Host "⚠ DLL is x86 but current PowerShell is x64 — restarting under x86..."
    $ps32 = "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $ps32)) { throw "32-bit PowerShell not found at $ps32" }
    & $ps32 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}
elseif ($dllArch -eq "x64" -and -not $is64PS) {
    Write-Host "⚠ DLL is x64 but current PowerShell is x86 — restarting under x64..."
    $ps64 = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $ps64)) { throw "64-bit PowerShell not found at $ps64" }
    & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}

Write-Host "✅ DLL architecture = $dllArch, PowerShell architecture = $(if($is64PS){"x64"}else{"x86"})"

# === 2) Загружаем DLL и запускаем payload ===
Add-Type -Path $dllPath -ErrorAction Stop
$instance = New-Object Company.SafeIngest.SafeIngest
$instance.RunBase64File((Resolve-Path ".\base64.txt").Path)
Write-Host "✅ Payload executed successfully."
