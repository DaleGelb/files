﻿# Путь к файлу с перевёрнутым base64
$path = "base64.txt"

# Читаем base64 из файла
$base64 = Get-Content -Path $path -Raw

# Разворачиваем строку обратно
$chars = $base64.ToCharArray()
[Array]::Reverse($chars)
$fixedBase64 = -join $chars

# Декодируем в байты
$bytes = [System.Convert]::FromBase64String($fixedBase64)

try {
    # Загружаем в память как .NET Assembly
    $asm = [System.Reflection.Assembly]::Load($bytes)
} catch {
    Write-Host "❌ Ошибка загрузки Assembly: $($_.Exception.Message)"
    exit 1
}

# Получаем точку входа
$entry = $asm.EntryPoint
if (-not $entry) {
    Write-Host "⚠️ Assembly загружен, но не содержит точку входа (Main)."
    exit 0
}

# Создаём объект, если Main нестатический
$instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }

# Определяем параметры строго по количеству аргументов
$paramCount = $entry.GetParameters().Count
switch ($paramCount) {
    0 { $argsToPass = @() }
    1 { $argsToPass = ,([string[]]@()) }
    default {
        Write-Host "⚠️ Main имеет $paramCount параметров — скрипт не умеет это обрабатывать."
        exit 1
    }
}

try {
    Write-Host "▶ Запуск $($entry.DeclaringType.FullName).$($entry.Name) с $paramCount параметрами"
    $entry.Invoke($instance, $argsToPass)
} catch {
    Write-Host "❌ Ошибка при выполнении Main: $($_.Exception.Message)"
    exit 1
}
