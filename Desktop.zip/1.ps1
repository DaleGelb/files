﻿# Путь к файлу с перевёрнутым base64
$path = "base64.txt"

try {
    # Читаем base64 из файла
    $base64 = Get-Content -Path $path -Raw

    # Разворачиваем строку обратно
    $chars = $base64.ToCharArray()
    [Array]::Reverse($chars)
    $fixedBase64 = -join $chars

    # Декодируем в байты
    $bytes = [System.Convert]::FromBase64String($fixedBase64)

    # Пробуем загрузить сборку
    $asm = [System.Reflection.Assembly]::Load($bytes)
} catch {
    Write-Host "❌ Ошибка загрузки Assembly: $($_.Exception.Message)"
    exit 1
}

# Получаем точку входа
$entry = $asm.EntryPoint
if (-not $entry) {
    Write-Host "⚠️ Сборка загружена, но не содержит Main (точки входа)."
    exit 0
}

# Определяем параметры
if ($entry.GetParameters().Count -eq 0) {
    $params = @()                # Main()
} else {
    $params = ,([string[]]@())   # Main(string[] args)
}

try {
    # Если Main не static — создаём объект
    $instance = if ($entry.IsStatic) { $null } else { New-Object $entry.DeclaringType }

    Write-Host "▶ Запуск: $($entry.DeclaringType.FullName).$($entry.Name)"
    $entry.Invoke($instance, $params)
} catch {
    Write-Host "❌ Ошибка при выполнении Main: $($_.Exception.Message)"
    exit 1
}
