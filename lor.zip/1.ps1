﻿# 1.ps1
# Автоматически находит путь к InstallUtil для .NET 4 и запускает /u ClassLibrary2.dll

# Определяем путь к Windows и InstallUtil
$frameworkDir = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319"
$installUtil = Join-Path $frameworkDir "InstallUtil.exe"

if (-not (Test-Path $installUtil)) {
    Write-Error "InstallUtil.exe not found at $installUtil"
    exit 1
}

# Путь к твоей DLL (лежит в том же каталоге, что и скрипт)
$dllPath = Join-Path (Get-Location) "ClassLibTexture.dll"
if (-not (Test-Path $dllPath)) {
    Write-Error "ClassLibrary2.dll not found at $dllPath"
    exit 1
}

Write-Host "Running InstallUtil..." -ForegroundColor Cyan
& $installUtil /u $dllPath
Write-Host "Done." -ForegroundColor Green
